import { Component } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { RegistrationService } from '../registration.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  constructor(private service: RegistrationService){}
  profileForm = new FormGroup({
    email:new FormControl(''),
    password:new FormControl(''),
});

login(){
  console.log("profileForm",this.profileForm.value)
  this.service.login(this.profileForm.value).subscribe((data:any)=>{
    console.log("data msg",data);
    if(!data.success){
      console.log("invalid user pw");
    }

  },
  error =>console.log("isdvd"));
}

}
