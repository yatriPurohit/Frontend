import { Component } from '@angular/core';

@Component({
  selector: 'app-homepag',
  templateUrl: './homepag.component.html',
  styleUrls: ['./homepag.component.scss']
})
export class HomepagComponent {
  sideBarOpen = true;
  name = 'Angular';
imageArr = [
  'https://helpx.adobe.com/content/dam/help/en/photoshop/using/convert-color-image-black-white/jcr_content/main-pars/before_and_after/image-before/Landscape-Color.jpg',
  'https://hatrabbits.com/wp-content/uploads/2017/01/random.jpg'
];
}




