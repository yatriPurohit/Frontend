import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(public http:HttpClient) { }
  protected(data:any){
    return this.http.get("http://localhost:4000/api/product/getdata",data);
  }
}
